"""Read-only Azure capacity/pricing and upstream release checks."""
import json
import pathlib
import subprocess
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

ROOT = pathlib.Path(__file__).resolve().parent
SUB = '624b9504-0d31-49f7-a880-e6adb18cd0f7'

def az(*args):
    return json.loads(subprocess.check_output(['az', *args, '--subscription', SUB, '-o', 'json'], text=True))

def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Zammad-deployment-preflight'})
    with urllib.request.urlopen(req, timeout=60) as response:
        return json.load(response)

def prices():
    query = "armRegionName eq 'southindia' and serviceName eq 'Virtual Machines' and armSkuName eq 'Standard_D4s_v5' and priceType eq 'Consumption'"
    return get('https://prices.azure.com/api/retail/prices?' + urllib.parse.urlencode({'$filter': query}))

tasks = {
    'skus': lambda: az('vm', 'list-skus', '--location', 'southindia', '--size', 'Standard_D4s_v5', '--all', '--query', '[].{name:name,restrictions:restrictions}'),
    'quota': lambda: az('vm', 'list-usage', '--location', 'southindia', '--query', "[?contains(name.value, 'standardDSv5Family') || name.value=='cores'].{name:name.value,current:currentValue,limit:limit}"),
    'prices': prices,
    'release': lambda: get('https://api.github.com/repos/zammad/zammad-docker-compose/releases/latest'),
    'groups': lambda: az('group', 'list', '--query', "[?name=='rg-zammad-petclinic'].{name:name,location:location}"),
}
results = {}
with ThreadPoolExecutor(max_workers=5) as pool:
    futures = {name: pool.submit(fn) for name, fn in tasks.items()}
    for name, future in futures.items():
        try:
            results[name] = future.result()
        except Exception as exc:
            results[name] = {'error': str(exc)}
ROOT.joinpath('preflight.json').write_text(json.dumps(results, indent=2))
for name in ('skus', 'quota', 'groups'):
    print(name, json.dumps(results[name]))
for row in results['prices'].get('Items', []):
    print('price', json.dumps({k: row.get(k) for k in ('productName','skuName','retailPrice','unitOfMeasure','currencyCode','effectiveStartDate')}))
print('release', json.dumps({k: results['release'].get(k) for k in ('tag_name','published_at','html_url','error')}))
