#!/bin/zsh
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
cd -- "${0:A:h}"
python3 manage.py stop
printf "\nPress Enter to close.\n"
read
