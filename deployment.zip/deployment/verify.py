"""Verify TLS, authenticated APIs, a labelled smoke-test ticket, and search."""
import json
import http.cookiejar
import html.parser
import pathlib
import time
import urllib.parse
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parent
access = json.loads(ROOT.joinpath('private/access.json').read_text())
base = access['url']
results = {'url': base, 'verified_at': datetime.now(timezone.utc).isoformat(), 'checks': {}}
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
csrf_token = None

class MetaParser(html.parser.HTMLParser):
    token = None
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'meta' and attrs.get('name') == 'csrf-token':
            self.token = attrs.get('content')

def request(path, data=None, authenticated=True):
    headers = {'Accept': 'text/html' if path == '/' else 'application/json', 'X-Zammad-Suppress-Notifications': 'true'}
    if authenticated:
        headers['Authorization'] = 'Token token=' + access['api_token']
    if data is not None:
        headers['Content-Type'] = 'application/json'
        headers['Origin'] = base
        if csrf_token:
            headers['X-CSRF-Token'] = csrf_token
    req = urllib.request.Request(base + path, headers=headers, data=json.dumps(data).encode() if data is not None else None)
    try:
        with opener.open(req, timeout=60) as response:
            payload = response.read()
            response_csrf = response.headers.get('X-CSRF-Token')
            if response_csrf:
                globals()['csrf_token'] = response_csrf
            return response.status, json.loads(payload) if 'application/json' in response.headers.get('Content-Type', '') else payload.decode()
    except urllib.error.HTTPError as error:
        try:
            payload = json.loads(error.read())
            message = payload.get('error') or payload.get('message') or 'Request rejected'
        except Exception:
            message = 'Non-JSON error response'
        raise SystemExit(f'{path}: HTTP {error.code}: {message}') from None

status, page = request('/', authenticated=False)
results['checks']['https'] = status
parser = MetaParser()
parser.feed(page)
csrf_token = parser.token
status, _ = request('/api/v1/signin', {'username': access['username'], 'password': access['password'], 'remember_me': False, 'fingerprint': uuid.uuid4().hex}, authenticated=False)
status, session_user = request('/api/v1/users/me', authenticated=False)
assert session_user['login'] == access['username'], 'Browser-session login failed'
results['checks']['password_login'] = status
print('HTTPS and password login passed.', flush=True)
# Use a fresh cookie jar for token checks so session auth cannot mask a bad API token.
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
csrf_token = None
status, user = request('/api/v1/users/me')
assert user['login'] == access['username'], 'Unexpected API user'
results['checks']['authenticated_api'] = status
print('Scoped API token passed.', flush=True)
status, kb = request('/api/v1/knowledge_bases/init', {})
results['checks']['knowledge_base_api'] = status
title = '[Deployment check] Zammad Petclinic API and search'
marker = ROOT / 'smoke-ticket.json'
if marker.exists():
    ticket = json.loads(marker.read_text())
else:
    status, ticket = request('/api/v1/tickets', {
        'title': title, 'group': 'Users', 'customer': 'demo.customer@petclinic.example',
        'state': 'closed', 'priority': '1 low',
        'article': {'subject': 'Installation verification',
                    'body': 'Synthetic deployment verification only. Confirms ticket creation and search; this is not a reported Spring Petclinic defect.',
                    'type': 'note', 'internal': True}
    })
    assert status == 201, status
    marker.write_text(json.dumps({'id': ticket['id'], 'number': ticket['number']}, indent=2))
results['checks']['ticket_id'] = ticket['id']
status, loaded = request('/api/v1/tickets/' + str(ticket['id']))
assert loaded['title'] == title
results['checks']['ticket_read'] = status
for attempt in range(12):
    query = urllib.parse.urlencode({'query': 'number:' + str(ticket['number']), 'limit': 10})
    status, found = request('/api/v1/tickets/search?' + query)
    if any(row['id'] == ticket['id'] for row in found):
        results['checks']['search'] = 'passed'
        break
    time.sleep(5)
else:
    raise RuntimeError('Ticket not found in search after 60 seconds')
ROOT.joinpath('verification.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
