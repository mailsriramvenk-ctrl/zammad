#!/usr/bin/env bash
set -euo pipefail
umask 077
export AZCOPY_AUTO_LOGIN_TYPE=MSI
backup_path=$(docker volume inspect zammad_zammad-backup --format '{{.Mountpoint}}')
if ! find "$backup_path" -type f -name '*.gz' -print -quit | grep -q .; then
  echo 'No completed compressed backup found; refusing an empty upload.' >&2
  exit 1
fi
# The vendor backup container retains 7 daily copies locally. Copy new files only.
azcopy copy "$backup_path/*" 'https://__STORAGE__.blob.core.windows.net/zammad/application/' --recursive=true --overwrite=ifSourceNewer
mkdir -p /root/zammad-config-backup
tar -czf /root/zammad-config-backup/config.tar.gz -C /opt/zammad .env docker-compose.yml local
azcopy copy /root/zammad-config-backup/config.tar.gz "https://__STORAGE__.blob.core.windows.net/zammad/config/$(date -u +%Y-%m-%d)/config.tar.gz" --overwrite=true
