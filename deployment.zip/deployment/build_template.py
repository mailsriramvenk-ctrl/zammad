"""Build the reviewable ARM template; no Azure API calls."""
import base64
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
PRIVATE = ROOT / 'private'
PRIVATE.mkdir(mode=0o700, exist_ok=True)
KEY = PRIVATE / 'zammad_vm'
if not KEY.exists():
    subprocess.run(['ssh-keygen', '-q', '-t', 'rsa', '-b', '3072', '-N', '', '-C', 'zammad-petclinic', '-f', str(KEY)], check=True)
HOST = 'petclinic-support-624b9504.southindia.cloudapp.azure.com'
STORE = 'stzammad624b9504'
files = []
for name in ('install-host.sh', 'bootstrap.rb', 'compose.override.yml', 'upload-backups.sh', 'snapshot-before-stop.sh'):
    content = ROOT.joinpath(name).read_text().replace('__HOSTNAME__', HOST).replace('__STORAGE__', STORE)
    files.append({'path': '/opt/zammad-bootstrap/' + name, 'permissions': '0700' if name.endswith('.sh') else '0600', 'content': content})
cloud = '#cloud-config\n' + json.dumps({'write_files': files, 'runcmd': [['bash', '/opt/zammad-bootstrap/install-host.sh']]})
ROOT.joinpath('cloud-init.json').write_text(cloud)

def rid(kind, name):
    return f"[resourceId('{kind}', '{name}')]"

def resource(resource_type, name, version, properties, depends=(), **extra):
    result = {'type': resource_type, 'apiVersion': version, 'name': name, 'properties': properties, **extra}
    if depends:
        result['dependsOn'] = list(depends)
    return result

location = 'southindia'
tags = {'application': 'zammad-petclinic', 'purpose': 'on-demand-prototype', 'managedBy': 'workspace-deployment'}
resources = []
resources.append(resource('Microsoft.Network/networkSecurityGroups', 'nsg-zammad', '2023-11-01', {'securityRules': [
    {'name': 'allow-web', 'properties': {'priority': 100, 'protocol': 'Tcp', 'access': 'Allow', 'direction': 'Inbound', 'sourceAddressPrefix': '*', 'sourcePortRange': '*', 'destinationAddressPrefix': '*', 'destinationPortRanges': ['80', '443']}}
]}, location=location, tags=tags))
resources.append(resource('Microsoft.Network/virtualNetworks', 'vnet-zammad', '2023-11-01', {'addressSpace': {'addressPrefixes': ['10.70.0.0/16']}, 'subnets': [{'name': 'default', 'properties': {'addressPrefix': '10.70.1.0/24', 'networkSecurityGroup': {'id': rid('Microsoft.Network/networkSecurityGroups', 'nsg-zammad')}}}]}, [rid('Microsoft.Network/networkSecurityGroups', 'nsg-zammad')], location=location, tags=tags))
resources.append(resource('Microsoft.Network/publicIPAddresses', 'pip-zammad', '2023-11-01', {'publicIPAllocationMethod': 'Static', 'publicIPAddressVersion': 'IPv4', 'dnsSettings': {'domainNameLabel': HOST.split('.')[0]}}, location=location, sku={'name': 'Standard'}, tags=tags))
resources.append(resource('Microsoft.Network/networkInterfaces', 'nic-zammad', '2023-11-01', {'ipConfigurations': [{'name': 'primary', 'properties': {'privateIPAllocationMethod': 'Dynamic', 'subnet': {'id': "[resourceId('Microsoft.Network/virtualNetworks/subnets', 'vnet-zammad', 'default')]"}, 'publicIPAddress': {'id': rid('Microsoft.Network/publicIPAddresses', 'pip-zammad')}}}]}, [rid('Microsoft.Network/virtualNetworks', 'vnet-zammad'), rid('Microsoft.Network/publicIPAddresses', 'pip-zammad')], location=location, tags=tags))
resources.append(resource('Microsoft.Compute/virtualMachines', 'vm-zammad-petclinic', '2024-03-01', {
    'hardwareProfile': {'vmSize': 'Standard_D4s_v5'},
    'storageProfile': {'imageReference': {'publisher': 'Canonical', 'offer': 'ubuntu-24_04-lts', 'sku': 'server', 'version': 'latest'}, 'osDisk': {'name': 'disk-zammad-os', 'createOption': 'FromImage', 'diskSizeGB': 128, 'managedDisk': {'storageAccountType': 'StandardSSD_LRS'}, 'deleteOption': 'Detach'}},
    'osProfile': {'computerName': 'zammad-petclinic', 'adminUsername': 'azureadmin', 'customData': base64.b64encode(cloud.encode()).decode(), 'linuxConfiguration': {'disablePasswordAuthentication': True, 'provisionVMAgent': True, 'ssh': {'publicKeys': [{'path': '/home/azureadmin/.ssh/authorized_keys', 'keyData': KEY.with_suffix('.pub').read_text().strip()}]}}},
    'networkProfile': {'networkInterfaces': [{'id': rid('Microsoft.Network/networkInterfaces', 'nic-zammad')}]},
    'diagnosticsProfile': {'bootDiagnostics': {'enabled': True}}
}, [rid('Microsoft.Network/networkInterfaces', 'nic-zammad')], location=location, identity={'type': 'SystemAssigned'}, tags=tags))
resources.append(resource('Microsoft.Storage/storageAccounts', STORE, '2023-05-01', {'minimumTlsVersion': 'TLS1_2', 'supportsHttpsTrafficOnly': True, 'allowBlobPublicAccess': False, 'allowSharedKeyAccess': False, 'accessTier': 'Hot'}, location=location, kind='StorageV2', sku={'name': 'Standard_LRS'}, tags=tags))
resources.append(resource('Microsoft.Storage/storageAccounts/blobServices/containers', STORE + '/default/zammad', '2023-05-01', {'publicAccess': 'None'}, [rid('Microsoft.Storage/storageAccounts', STORE)]))
resources.append(resource('Microsoft.Storage/storageAccounts/managementPolicies', STORE + '/default', '2023-05-01', {'policy': {'rules': [{'enabled': True, 'name': 'expire-30-days', 'type': 'Lifecycle', 'definition': {'actions': {'baseBlob': {'delete': {'daysAfterModificationGreaterThan': 30}}}, 'filters': {'blobTypes': ['blockBlob'], 'prefixMatch': ['zammad/']}}}]}}, [rid('Microsoft.Storage/storageAccounts', STORE)]))
resources.append(resource('Microsoft.Authorization/roleAssignments', "[guid(resourceGroup().id, 'zammad-backup-writer')]", '2022-04-01', {'roleDefinitionId': "[subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'ba92f5b4-2d11-453d-a403-e96b0029c9fe')]", 'principalId': "[reference(resourceId('Microsoft.Compute/virtualMachines', 'vm-zammad-petclinic'), '2024-03-01', 'Full').identity.principalId]", 'principalType': 'ServicePrincipal'}, [rid('Microsoft.Compute/virtualMachines', 'vm-zammad-petclinic'), rid('Microsoft.Storage/storageAccounts', STORE)], scope=f"[format('Microsoft.Storage/storageAccounts/{{0}}', '{STORE}')]"))
template = {'$schema': 'https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#', 'contentVersion': '1.0.0.0', 'resources': resources, 'outputs': {'url': {'type': 'string', 'value': 'https://' + HOST}, 'publicIP': {'type': 'string', 'value': "[reference(resourceId('Microsoft.Network/publicIPAddresses', 'pip-zammad')).ipAddress]"}, 'backupStorage': {'type': 'string', 'value': STORE}}}
ROOT.joinpath('azuredeploy.json').write_text(json.dumps(template, indent=2) + '\n')
print('Prepared ARM template, cloud-init, and private SSH recovery key. No Azure changes made.')
