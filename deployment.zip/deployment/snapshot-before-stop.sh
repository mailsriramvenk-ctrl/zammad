#!/usr/bin/env bash
# Consistent snapshot for an on-demand session, uploaded before deallocation.
set -euo pipefail
umask 077
cd /opt/zammad
backup_path=$(docker volume inspect zammad_zammad-backup --format '{{.Mountpoint}}')
storage_path=$(docker volume inspect zammad_zammad-storage --format '{{.Mountpoint}}')
stamp=$(date -u +%Y%m%dT%H%M%SZ)
mkdir -p "$backup_path/on-demand"
docker compose stop zammad-nginx zammad-scheduler zammad-websocket zammad-railsserver
trap 'docker compose up -d zammad-nginx zammad-scheduler zammad-websocket zammad-railsserver' EXIT
docker compose exec -T zammad-postgresql sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" pg_dump -h 127.0.0.1 -U "$POSTGRES_USER" --clean --if-exists "$ZAMMAD_DB"' | gzip >"$backup_path/on-demand/${stamp}_database.psql.gz.partial"
mv "$backup_path/on-demand/${stamp}_database.psql.gz.partial" "$backup_path/on-demand/${stamp}_database.psql.gz"
tar -czf "$backup_path/on-demand/${stamp}_storage.tar.gz.partial" -C "$storage_path" .
mv "$backup_path/on-demand/${stamp}_storage.tar.gz.partial" "$backup_path/on-demand/${stamp}_storage.tar.gz"
gzip -t "$backup_path/on-demand/${stamp}_database.psql.gz" "$backup_path/on-demand/${stamp}_storage.tar.gz"
/usr/local/sbin/zammad-upload-backups
find "$backup_path/on-demand" -type f -name '*.gz' -mtime +7 -delete
echo 'ON_DEMAND_SNAPSHOT_UPLOADED'
