# Runs once inside the initialized Zammad Rails container, before public access.
require 'json'
require 'securerandom'
UserInfo.current_user_id = 1
data = JSON.parse(File.read('/tmp/bootstrap-input.json'))
admin = User.find_by(login: 'petclinic-admin')
unless admin
  admin = User.create!(
    login: 'petclinic-admin', email: 'admin@petclinic.example',
    firstname: 'Petclinic', lastname: 'Administrator',
    password: data.fetch('password'), active: true,
    roles: Role.where(name: %w[Admin Agent]),
    group_ids_access_map: Group.all.to_h { |g| [g.id, ['full']] }
  )
end
UserInfo.current_user_id = admin.id
{
  'system_init_done' => true,
  'organization' => 'Spring Petclinic Support Lab',
  'product_name' => 'Petclinic Support',
  'fqdn' => data.fetch('hostname'),
  'http_type' => 'https',
  'timezone_default' => 'Asia/Kolkata',
  'user_create_account' => false,
  'api_password_access' => false,
  'api_token_access' => true
}.each { |name, value| Setting.set(name, value) }
unless User.exists?(email: 'demo.customer@petclinic.example')
  User.create!(login: 'demo.customer@petclinic.example', email: 'demo.customer@petclinic.example',
               firstname: 'Demo', lastname: 'Customer', active: true, roles: Role.where(name: 'Customer'))
end
# Email remains unconfigured for this synthetic-data lab.
Channel.where(area: 'Email::Notification').update_all(active: false)
token = Token.find_by(action: 'api', user_id: admin.id, name: 'Petclinic data import')
token ||= Token.create!(action: 'api', persistent: true, user_id: admin.id,
                       name: 'Petclinic data import', expires_at: 90.days.from_now,
                       preferences: { permission: %w[ticket.agent knowledge_base.editor admin.user] })
token.update!(preferences: { permission: %w[ticket.agent knowledge_base.editor admin.user] })
File.write('/tmp/zammad-access.json', JSON.pretty_generate({
  url: "https://#{data.fetch('hostname')}", username: admin.login,
  email: admin.email, password: data.fetch('password'), api_token: token.token,
  api_token_expires_at: token.expires_at,
  petclinic_repository: 'https://github.com/spring-projects/spring-petclinic'
}))
File.chmod(0600, '/tmp/zammad-access.json')
puts 'Administrator configured; API token stored in the private access file.'
