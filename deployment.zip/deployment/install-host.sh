#!/usr/bin/env bash
set -euo pipefail
umask 077
export DEBIAN_FRONTEND=noninteractive
hostname_fqdn='__HOSTNAME__'
storage_account='__STORAGE__'
apt-get update
apt-get install -y docker.io docker-compose-v2 git curl ca-certificates python3
systemctl enable --now docker
printf 'vm.max_map_count=262144\n' >/etc/sysctl.d/90-zammad.conf
sysctl --system
if [ ! -d /opt/zammad/.git ]; then
  git clone --depth 1 --branch v17.5.5 https://github.com/zammad/zammad-docker-compose.git /opt/zammad
fi
cd /opt/zammad
mkdir -p local
cp /opt/zammad-bootstrap/compose.override.yml local/https.yml
cp /opt/zammad-bootstrap/bootstrap.rb local/bootstrap.rb
printf '%s {\n  encode zstd gzip\n  reverse_proxy zammad-nginx:8080\n}\n' "$hostname_fqdn" >local/Caddyfile
export ZAMMAD_BOOTSTRAP_HOSTNAME="$hostname_fqdn"
python3 - <<'PY'
import json, os, pathlib, secrets
root = pathlib.Path('/opt/zammad')
env = root / '.env'
if not env.exists():
    env.write_text('\n'.join([
        'COMPOSE_PROJECT_NAME=zammad',
        'COMPOSE_FILE=docker-compose.yml:local/https.yml',
        'POSTGRES_PASS=' + secrets.token_hex(32),
        'POSTGRES_SUPERUSER_PASS=' + secrets.token_hex(32),
        'NGINX_EXPOSE_PORT=127.0.0.1:8080',
        'NGINX_SERVER_SCHEME=https',
        'ZAMMAD_HTTP_TYPE=https',
        'ZAMMAD_FQDN=' + os.environ['ZAMMAD_BOOTSTRAP_HOSTNAME'],
        'TZ=Asia/Kolkata', 'BACKUP_TIME=03:00', 'BACKUP_ON_START=true', 'HOLD_DAYS=7',
        'ELASTICSEARCH_JAVA_OPTS=-Xms2g -Xmx2g',
        'POSTGRES_MAX_CONNECTIONS=200',
        ''
    ]))
    env.chmod(0o600)
secret = pathlib.Path('/root/zammad-bootstrap-input.json')
if not secret.exists():
    secret.write_text(json.dumps({'hostname': os.environ['ZAMMAD_BOOTSTRAP_HOSTNAME'],
                                 'password': 'Pc9!Aa' + secrets.token_urlsafe(24)}))
    secret.chmod(0o600)
PY
docker compose config --quiet
docker compose pull
# Start all application services, leaving the public TLS proxy stopped until setup is done.
docker compose up -d zammad-elasticsearch zammad-init zammad-nginx zammad-scheduler zammad-websocket zammad-backup
ready=false
for attempt in $(seq 1 90); do
  if curl -fsS http://127.0.0.1:8080/ >/dev/null; then ready=true; break; fi
  sleep 10
done
if [ "$ready" != true ]; then echo 'Zammad did not become ready within 15 minutes.' >&2; exit 1; fi
if [ ! -f /root/zammad-access.json ]; then
  docker compose cp local/bootstrap.rb zammad-railsserver:/tmp/bootstrap.rb
  docker compose cp /root/zammad-bootstrap-input.json zammad-railsserver:/tmp/bootstrap-input.json
  docker compose exec -T -u root zammad-railsserver chmod 644 /tmp/bootstrap.rb /tmp/bootstrap-input.json
  docker compose exec -T zammad-railsserver bundle exec rails runner /tmp/bootstrap.rb
  docker compose cp zammad-railsserver:/tmp/zammad-access.json /root/zammad-access.json
  chmod 600 /root/zammad-access.json
  docker compose exec -T -u root zammad-railsserver rm -f /tmp/bootstrap-input.json /tmp/zammad-access.json /tmp/bootstrap.rb
fi
docker compose up -d caddy
mkdir -p /opt/zammad-backup-tools
curl -fsSL --retry 3 https://aka.ms/downloadazcopy-v10-linux -o /opt/zammad-backup-tools/azcopy.tar.gz
tar -xzf /opt/zammad-backup-tools/azcopy.tar.gz -C /opt/zammad-backup-tools
install -m 0755 /opt/zammad-backup-tools/azcopy_linux_amd64_*/azcopy /usr/local/bin/azcopy
sed "s/__STORAGE__/$storage_account/g" /opt/zammad-bootstrap/upload-backups.sh >/usr/local/sbin/zammad-upload-backups
chmod 700 /usr/local/sbin/zammad-upload-backups
install -m 0700 /opt/zammad-bootstrap/snapshot-before-stop.sh /usr/local/sbin/zammad-snapshot-before-stop
cat >/etc/systemd/system/zammad-upload-backups.service <<'EOF'
[Unit]
Description=Copy Zammad backups to private Azure Blob storage
After=network-online.target docker.service
Wants=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/zammad-upload-backups
EOF
cat >/etc/systemd/system/zammad-upload-backups.timer <<'EOF'
[Unit]
Description=Daily Zammad off-VM backup upload
[Timer]
OnCalendar=*-*-* 04:00:00 Asia/Kolkata
Persistent=true
[Install]
WantedBy=timers.target
EOF
systemctl daemon-reload
systemctl enable --now zammad-upload-backups.timer
printf 'Installation completed.\n' >/root/zammad-install-complete
