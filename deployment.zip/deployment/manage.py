"""Start, deallocate, inspect, or run maintenance on the dedicated Zammad VM."""
import argparse
import json
import pathlib
import subprocess
import time
import urllib.request
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parent
SUB = '624b9504-0d31-49f7-a880-e6adb18cd0f7'
RG = 'rg-zammad-petclinic'
VM = 'vm-zammad-petclinic'
HOST = 'petclinic-support-624b9504.southindia.cloudapp.azure.com'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('action', choices=['start', 'stop', 'status', 'inspect', 'access', 'run'])
parser.add_argument('--script', type=pathlib.Path)
args = parser.parse_args()

def az(*items):
    return json.loads(subprocess.check_output(['az', *items, '--subscription', SUB, '--only-show-errors', '-o', 'json'], text=True) or 'null')

def run(script):
    return az('vm', 'run-command', 'invoke', '-g', RG, '-n', VM, '--command-id', 'RunShellScript', '--scripts', script)

if args.action in ('start', 'stop'):
    if args.action == 'stop':
        states = az('vm', 'get-instance-view', '-g', RG, '-n', VM, '--query', 'instanceView.statuses[].code')
        if 'PowerState/deallocated' in states:
            print('VM is already deallocated.')
            raise SystemExit(0)
        print('Taking and uploading a session-end backup before deallocation.', flush=True)
        backup = run('/usr/local/sbin/zammad-snapshot-before-stop')
        messages = '\n'.join(value.get('message', '') for value in backup.get('value', []))
        if 'ON_DEMAND_SNAPSHOT_UPLOADED' not in messages:
            raise RuntimeError('Backup did not confirm success; VM left allocated. Inspect the backup service before retrying.\n' + messages)
    print(('Starting' if args.action == 'start' else 'Deallocating') + ' Zammad VM.', flush=True)
    az('vm', 'start' if args.action == 'start' else 'deallocate', '-g', RG, '-n', VM)
    if args.action == 'start':
        print('VM started; waiting for Zammad HTTPS readiness.', flush=True)
        for attempt in range(40):
            try:
                req = urllib.request.Request('https://' + HOST, headers={'Accept': 'text/html'})
                with urllib.request.urlopen(req, timeout=10) as response:
                    if response.status == 200:
                        break
            except Exception:
                pass
            time.sleep(5)
        else:
            raise RuntimeError('VM is running but Zammad did not become ready; inspect services.')
    states = az('vm', 'get-instance-view', '-g', RG, '-n', VM, '--query', 'instanceView.statuses[].code')
    expected = 'PowerState/running' if args.action == 'start' else 'PowerState/deallocated'
    if expected not in states:
        raise RuntimeError('Unexpected VM state: ' + str(states))
    with ROOT.joinpath('lifecycle-events.jsonl').open('a') as events:
        events.write(json.dumps({'timestamp': datetime.now(timezone.utc).isoformat(), 'action': args.action, 'state': expected, 'backup_uploaded': args.action == 'stop'}) + '\n')
    print('https://' + HOST if args.action == 'start' else 'VM deallocated; compute billing stopped. Disk, IP, and storage charges continue.')
elif args.action == 'status':
    print(json.dumps(az('vm', 'get-instance-view', '-g', RG, '-n', VM, '--query', 'instanceView.statuses'), indent=2))
elif args.action == 'inspect':
    result = run('cloud-init status; test ! -f /root/zammad-install-complete || cat /root/zammad-install-complete; cd /opt/zammad && docker compose ps -a; tail -n 25 /var/log/cloud-init-output.log')
    for value in result.get('value', []):
        print(value.get('message', ''))
elif args.action == 'access':
    result = run('cat /root/zammad-access.json')
    stdout = '\n'.join(v.get('message', '') for v in result['value'])
    if '[stdout]' in stdout:
        stdout = stdout.split('[stdout]', 1)[1].split('[stderr]', 1)[0]
    data = json.loads(stdout.strip())
    folder = ROOT / 'private'
    folder.mkdir(mode=0o700, exist_ok=True)
    path = folder / 'access.json'
    path.touch(mode=0o600, exist_ok=True)
    path.chmod(0o600)
    path.write_text(json.dumps(data, indent=2) + '\n')
    print('Credentials saved locally to deployment/private/access.json; not printed.')
elif args.action == 'run':
    if not args.script:
        parser.error('--script is required for run')
    result = run(args.script.read_text())
    for value in result.get('value', []):
        print(value.get('message', ''))
