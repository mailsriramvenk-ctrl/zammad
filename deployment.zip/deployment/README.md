# Zammad / Spring Petclinic support lab

Target: South India, subscription `624b9504-0d31-49f7-a880-e6adb18cd0f7`, dedicated resource group `rg-zammad-petclinic`.

Deployed and verified on 10 November 2026: Zammad 7.2.2, Compose commit `9d727721f2c40a8b38497d2098aeed0039870005`. URL: https://petclinic-support-624b9504.southindia.cloudapp.azure.com . Login credentials and the 90-day import token are in the private `deployment/private/access.json` file; they are excluded from Git. The administrator login is `petclinic-admin`.

Handoff state: **Stopped (deallocated)** after a successful final backup. Start the VM before opening the site. Persistent disk, static IP, and backup storage charges continue; compute charges are stopped.

HTTPS, password login, token authentication, knowledge-base API access, and ticket creation/read/search passed. A complete deallocate/start cycle preserved the same test ticket (ID 2), and those checks passed again. Backup files were independently listed in Azure Blob storage. See `verification.json`, `runtime-verification.json`, and `lifecycle-events.jsonl` for evidence. A full restore drill has not been performed.

The deployment uses a 4-vCPU, 16-GiB `Standard_D4s_v5` Linux VM with a 128-GiB Standard SSD OS disk, a static public IP with Azure DNS, the official Zammad Docker Compose release `v17.5.5`, Caddy HTTPS, and a private Blob backup container. PostgreSQL, Elasticsearch, and Redis are private to the Docker network. Port 8080 binds to localhost. Only ports 80 and 443 are publicly reachable; administration uses Azure VM Run Command. The local SSH key is a recovery credential; SSH is not exposed.

## Deployment

1. `python3 deployment/preflight.py` checks capacity, quota, and retail pricing.
2. `python3 deployment/build_template.py` builds the reviewable ARM template and cloud-init.
3. `python3 deployment/deploy.py` validates and creates Azure resources.
4. `python3 deployment/manage.py inspect` checks installation progress.
5. `python3 deployment/manage.py access` saves credentials to `deployment/private/access.json` with mode 0600, excluded from Git.

Resource provisioning is separate from application health. Only report successful installation after HTTPS, authentication, ticket/search APIs, and backup upload are verified.

## Run only when required

On this Mac, double-click `Start Zammad.command` or `Stop Zammad.command` in the deployment folder. They use your existing Azure CLI sign-in. Alternatively, from this workspace, run:

```sh
python3 deployment/manage.py start
python3 deployment/manage.py status
python3 deployment/manage.py stop
```

`stop` first pauses application writers, creates and uploads a consistent database/attachment snapshot, then calls Azure VM **deallocate**. A failed backup prevents deallocation so the error can be investigated. This preserves disks, backup storage, and the static hostname/IP while stopping compute billing. The site and API are unavailable while deallocated. Allow several minutes after starting for the database and search services to become ready. There is no automatic start or automatic shutdown schedule.

The equivalent direct Azure commands are:

```sh
az vm start --subscription 624b9504-0d31-49f7-a880-e6adb18cd0f7 --resource-group rg-zammad-petclinic --name vm-zammad-petclinic
az vm deallocate --subscription 624b9504-0d31-49f7-a880-e6adb18cd0f7 --resource-group rg-zammad-petclinic --name vm-zammad-petclinic
```

In the Azure portal, open the VM and use **Start** or **Stop**, then verify **Stopped (deallocated)**. Shutting down Linux alone can leave the VM allocated and billed.

South India retail compute price checked on 2026-11-10: USD 0.271/hour, or USD 21.68 for ten 8-hour sessions. Approximately USD 197.83 for 730 running hours. Disk, public IP, Blob storage, egress, and taxes are additional; actual agreement pricing may differ. The preflight JSON records the retail response. Capacity on a later start is subject to Azure availability.

## Backups and maintenance

The vendor backup container takes database/file backups on start and daily at 03:00 Asia/Kolkata, with 7 local copies. A persistent systemd timer uploads them to private Blob storage at 04:00 Asia/Kolkata; missed uploads are attempted at the next boot. Off-VM blobs expire after 30 days. A deallocated VM cannot run its local timers. The provided stop helper takes and uploads a fresh, consistent snapshot before every deallocation. Direct Azure portal/CLI stops preserve the disk but do not run this extra backup step. Restore testing is a separate operation and must not be represented as verified unless performed.

The backup uploader authenticates with the VM managed identity, restricted to Blob Data Contributor on this deployment's storage account. Shared keys and public Blob access are disabled. Configuration backups contain database credentials and must remain private.

Maintain OS and container security updates during planned running sessions. The official Compose release is pinned; review release notes, take and verify backups, then update deliberately. Container digests should be recorded after installation.

## Petclinic content

Source: https://github.com/spring-projects/spring-petclinic . This deployment hosts Zammad, not the Petclinic application. No bulk synthetic tickets or knowledge articles are loaded by the installer. Verification creates one clearly labelled, closed installation-check ticket. A demo customer and a scoped 90-day API token are prepared for a later import. Review repository features and pin a source commit when creating content; label simulated incidents clearly. Outbound email is not configured, and public self-registration is disabled.

## Removal

The resource group is dedicated to this lab. Deleting it removes the VM, disks, network, and backup account, including tickets and articles. Export and verify backups elsewhere before any deletion. No deletion is performed by these scripts.
