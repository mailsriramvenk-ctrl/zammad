"""Validate and deploy the reviewed Zammad stack into its dedicated resource group."""
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
SUB = '624b9504-0d31-49f7-a880-e6adb18cd0f7'
RG = 'rg-zammad-petclinic'

def az(*args):
    return json.loads(subprocess.check_output(['az', *args, '--subscription', SUB, '--only-show-errors', '-o', 'json'], text=True))

print('Creating dedicated resource group in South India.', flush=True)
az('group', 'create', '--name', RG, '--location', 'southindia', '--tags', 'application=zammad-petclinic', 'purpose=on-demand-prototype')
print('Validating deployment with Azure.', flush=True)
az('deployment', 'group', 'validate', '--resource-group', RG, '--name', 'zammad-initial', '--template-file', str(ROOT / 'azuredeploy.json'))
print('Deploying VM, network, persistent disk, and private backup storage.', flush=True)
result = az('deployment', 'group', 'create', '--resource-group', RG, '--name', 'zammad-initial', '--template-file', str(ROOT / 'azuredeploy.json'))
ROOT.joinpath('deployment-result.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result['properties'].get('outputs', {}), indent=2))
print('Azure resources provisioned. Zammad installation continues through cloud-init.', flush=True)
